import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Cadastro } from './pages/cadastro/cadastro';
import { Notas } from './pages/notas/notas';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'cadastro', component: Cadastro },
  { path: 'notas', component: Notas }, // Tela do print com o Jardim Neural e Bloco de Notas
  { path: '**', redirectTo: 'login' },
];